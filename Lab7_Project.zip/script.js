/* ===== AUTOMATIC SLIDESHOW ===== */
let slideIndex = 0;
function showSlides() {
    let slides = document.getElementsByClassName("slide");
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1; }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 3000);
}
showSlides();

/* ===== PROGRESS BAR ===== */
let progress = 0;
document.getElementById("increase").addEventListener("click", function () {
    if (progress < 100) {
        progress += 10;
        document.getElementById("progress-bar").style.width = progress + "%";
    } else {
        alert("Journey Completed 🌍");
    }
});

/* ===== COLLAPSIBLE ===== */
document.querySelector(".collapsible").addEventListener("click", function () {
    let content = document.querySelector(".content");
    content.style.display = content.style.display === "block" ? "none" : "block";
});
